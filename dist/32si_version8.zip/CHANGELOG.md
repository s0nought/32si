# v 8

2023.09.25

Added support for 5 maps:
- de_ansar
- de_inferno_winter
- de_rise
- de_cache
- de_clan4_stone

# v 7

2022.01.10

Added files:
- ripent.exe
- ripent_x64.exe
- Vluzacn's ZHLT v34.zip

Removed files:
- CheckForUpdates.bat
- scripts directory

Notes:
- No ent files were added in this update.

# v 6

2021.12.11

Added support for 5 maps:
- cs_vercetti
- cs_firstnoel
- de_morningsun
- de_arizona
- de_bretagne

# v 5

2021.12.02

Added support for 5 maps:
- cs_vendetta
- de_boondocks
- de_chernobyl
- de_japan
- de_manila

# v 4

2021.12.01

Added support for 5 maps:
- cs_thunder
- de_altstadt2k
- de_aztec2
- de_cevo_concrete2
- de_priory

# v 3

2021.11.13

Added support for 5 maps:
- cs_assault_hd
- de_best
- de_jungletemple
- de_season_css
- dm_farero

# v 2

2021.11.10

Added support for 5 maps:
- de_ahram
- de_cbble_cz
- de_lite
- de_rebelzone
- de_russka

# v 1

2021.11.07

Added support for 37 maps:
- as_coast
- as_evil
- as_midnight_docks
- concord_redone
- cs_bikiniresort
- cs_botanical
- cs_libre
- cs_mansion_cz_b2
- cs_mari
- cs_paris
- de_alcatraz
- de_allahakbar
- de_breeze
- de_bright
- de_burscheid
- de_callipolia
- de_cevo_crete
- de_fabrica
- de_fence_rc1
- de_flow_b4
- de_halla
- de_jihad
- de_korbin
- de_luxor
- de_mog
- de_mountainhamlet
- de_pipeline
- de_pripyat
- de_roadhouse
- de_rotterdam_cz
- de_seaside2k
- de_slap
- de_snowball
- de_stadium_cz
- de_sunday
- de_valence
- de_vine
